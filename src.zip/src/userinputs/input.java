package userinputs;

public class input {
	

	public static String Browser="IE";
	public static String url="https://www.ilabquality.com/";
	public static String browserpath="src/report/IEDriverServer.exe";
}
