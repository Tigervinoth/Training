package actions;


	import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

	public class ExcelFunction {
		
		public XSSFWorkbook wbook;
		public XSSFSheet wsheet;
		
		public ExcelFunction(String path,int sheet){

	    try {
			File excel2 = new File(path);
			FileInputStream fil  = new FileInputStream(excel2);
			
			wbook = new XSSFWorkbook(fil);
			wsheet = wbook.getSheetAt(sheet);
			
		//	FileOutputStream fout = new FileOutputStream(excel2);
		//	wbook.write(fout);
			
		} 
	    catch (Exception e) {
				System.out.println(e.getMessage());
		} 
		
		}
		public int rowcount(){
			int row = wsheet.getLastRowNum();
			return row;
		}
		public Double getnumericdata(int row,int col){
			
			Double data = wsheet.getRow(row).getCell(col).getNumericCellValue();
			return data;
		}

	public int getnumericdata1(int row,int col){
			
			int data = (int) wsheet.getRow(row).getCell(col).getNumericCellValue();
			return data;
		}
	
		public String getstringdata(int row,int col){
			
			
		/*	 DataFormatter formatter = new DataFormatter(); //creating formatter using the default locale
			 Cell cell = wsheet.getRow(row).getCell(col);
			 String data = formatter.formatCellValue(cell);
			return data;  */
			
			String data = wsheet.getRow(row).getCell(col).getRawValue();
			return data;
		}
		
	//	public void writedata(int row,int col,String value) throws IOException{
		//	wsheet.getRow(row).createCell(col).setCellValue(value);
			
			
			//	}
	}





