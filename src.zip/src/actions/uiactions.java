package actions;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;








import objects.pageobjects;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import userinputs.*;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class uiactions {
		
		protected static WebDriver driver;
		public static ExtentReports report;
		public static ExtentTest logger;
	
		static String path = "src/userinputs/path.txt"; 
	
		public static WebDriver browser(String browser,String strURL ) throws Exception
		{
			
			boolean browserFound= true;
			
			if(browser.toUpperCase().equals("FIREFOX")){
		    	FirefoxProfile fp = new FirefoxProfile();
		    	fp.setAcceptUntrustedCertificates(true);
		        driver = new FirefoxDriver(fp);
		        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		        logger.log(LogStatus.INFO, "IE Browser opened Successfully");
			}
		        				
							
			else if(browser.toUpperCase().equals("IE")){
				
				
				System.setProperty("webdriver.ie.driver",input.browserpath);
	  			driver=new InternetExplorerDriver();
	  			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	  			logger.log(LogStatus.INFO, "IE Browser opened Successfully");
			}
			
			else{
				browserFound = false;
			}		
			
			
			if (browserFound) {
				driver.manage().window().maximize();
				driver.get(strURL);
				return driver;
			}else{
				logger.log(LogStatus.FAIL, "Browser not opened");
				return null;
			}

	}
		


		
		public static void input(String UIName, String objTechName, String data) throws Exception{
			try{
				
			String[] path=pageobjects.Apply_online.split("|");
			String path1=path[0];
			String path2=path[1];
		
				WebDriverWait wait = new WebDriverWait(driver, 60);
				WebElement element = driver.findElement(ObjectMap.getLocator(objTechName));
				wait.until(ExpectedConditions.visibilityOf(element));
				element.clear();
				element.sendKeys(data);
				logger.log(LogStatus.PASS, UIName+" entered successfully");
				captureEvidence(UIName);
			 }
			 catch(Exception e){
				 logger.log(LogStatus.FAIL, UIName+" entered failed");
				 captureEvidence(UIName);
			
			 	}
			}
		
		public static void click(String UIName, String objTechName) throws Exception{
			
			try{
				
				WebDriverWait wait = new WebDriverWait(driver, 60); 
				WebElement elementToClick = driver.findElement(ObjectMap.getLocator(objTechName));
				wait.until(ExpectedConditions.elementToBeClickable(elementToClick));
				captureEvidence(UIName);
				elementToClick.click();
				logger.log(LogStatus.PASS, UIName+" Clicked successfully");
				
				
			}catch(Exception e){
				logger.log(LogStatus.FAIL, " Error in clicking the object "+UIName);
				captureEvidence(UIName);
				
			
			}
		}
		
				

		
		public static void closeBrowser() throws Exception{
			
			try{
				//report.close();
				driver.quit();
			}
			catch(Exception e){
				
			}
			
			}
		public static void createReport() throws Exception{
			
			String STEPREPORT_PATH=readFileAsString(path);
			report= new ExtentReports(STEPREPORT_PATH+"/report.html");
			
		}
		public static void Steplogs(String Stepname){
			try{
			logger=report.startTest(Stepname);
			}
			catch(Exception e){
				
			}
		}
		
		public static void savereport() throws InterruptedException{
			try{
			 report.endTest(logger);
			 Thread.sleep(1000);
			 report.flush();
					 
			}catch(Exception e){
				
			}
		}
	
		public enum properties{
			DISPLAYED,VISIBLE;
		}
		public static boolean ValidateObject(String UIName, String objectTechName, String PropertyToBeVerified) throws Exception {
			
			boolean ActualPropertyValue = false;
			String prop=PropertyToBeVerified.toUpperCase();
			try{
				switch (properties.valueOf(prop)){
				case DISPLAYED:
					ActualPropertyValue = driver.findElement(ObjectMap.getLocator(objectTechName)).isDisplayed();
					break;	
				case VISIBLE:						
				ActualPropertyValue = driver.findElement(ObjectMap.getLocator(objectTechName)).isEnabled();
				break;
				default: break;}
			}
			catch(Exception e){
			
				
					if(ActualPropertyValue==false){
						
						
						logger.log(LogStatus.FAIL, UIName+" is not "+PropertyToBeVerified+" --Stopped Execution");
						captureEvidence(UIName);
						savereport();
						
						//throw new UserDefinedException("<<< Unable to Find " + UIName + " >>> " + e.getMessage());
						Assert.assertTrue("<<< Couldn't Find " + UIName + " >>> ",false);
						//closeBrowser();

					}
					}
					if(ActualPropertyValue==true){
						
						logger.log(LogStatus.PASS, UIName+" is "+PropertyToBeVerified);
						captureEvidence(UIName);
						return true;	
			
				
					}
			
			return false;
		
		
		}

			
			public static String captureEvidence(String fieldname) throws Exception{
				try{
					String SCREENSHOT_PATH=readFileAsString(path);
					 Date date = new Date();
					 DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
					 DateFormat date2 = new SimpleDateFormat("yyyy_MM_dd");
					 String strimage = SCREENSHOT_PATH+"/"+date2.format(date)+"/"+fieldname+dateFormat.format(date)+".png";
					 File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
					 FileUtils.copyFile(scrFile, new File(strimage));
					 return strimage;
					 			
				}catch(Exception e){
					
					logger.log(LogStatus.INFO, "Unable to Capture Screenshot");
				}
				return null;
			}
		
			  public static String readFileAsString(String fileName)throws Exception 
			  { 
			    String data = ""; 
			    data = new String(Files.readAllBytes(Paths.get(fileName))); 
			    return data; 
			  } 
		

}
