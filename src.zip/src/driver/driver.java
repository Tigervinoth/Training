package driver;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import objects.pageobjects;

import org.junit.Test;

import userinputs.input;
import actions.*;

public class driver {
	
	
	@Test
	public void test() throws Exception {
	

		String strPathConfigFile="src/report/excel.xlsx";
		ExcelFunction excel = new ExcelFunction(strPathConfigFile,0);
		int row = excel.rowcount();
		int rows = row+1;
		
		uiactions.createReport();
		
		uiactions.Steplogs("Lauching the page");
		uiactions.browser(input.Browser, input.url);
		uiactions.click("CarearClick", pageobjects.careers);
		uiactions.click("Country Select", pageobjects.south_africa);
		uiactions.click("Job Link", pageobjects.job_link);
		uiactions.click("Apply", pageobjects.Apply_online);
		uiactions.ValidateObject("Username", pageobjects.name, "Displayed");
		
		for(int i=1;i<rows;i++){
			

				String name = excel.getstringdata(i,1);
				String email = excel.getstringdata(i,1);
				String phone = excel.getstringdata(i,1);
		
			
		uiactions.input("Username", pageobjects.name, name);
		uiactions.input("Email", pageobjects.email_id, email);
		uiactions.input("Phone", pageobjects.phone, phone);
		uiactions.click("Submit",pageobjects.send_app);
		
		}
		
		
		
		uiactions.savereport();
		uiactions.closeBrowser();
		
	}
	
	
	}
