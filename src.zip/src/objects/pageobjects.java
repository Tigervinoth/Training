package objects;

public class pageobjects {
	
		
		
			public static String careers="xpath|//*[@id=\"menu-item-1373\"]/a";

			public static String south_africa= "xpath|/html/body/section/div[2]/div/div/div/div[3]/div[2]/div/div/div[3]/div[2]/div/div/div[3]/a";

			public static String job_link="xpath|/html/body/section/div[2]/div/div/div/div[3]/div[2]/div/div/div/div/div/div[1]/div[1]/div[2]/span[1]/a";         

			public static String Apply_online="xpath|//*[@id=\"wpjb-scroll\"]/div[1]/a";

			public static String name="xpath|//*[@id=\"applicant_name\"]";

			public static String email_id="xpath|//*[@id=\"email\"]";

			public static String phone="xpath|//*[@id=\"phone\"]";

			public static String send_app="xpath|//*[@id=\"wpjb_submit\"]";

			public static String text="xpath|//*[@id=\"wpjb-apply-form\"]/fieldset[1]/div[5]/div/ul/li";

	}


